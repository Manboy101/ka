function bottomLayerContent() {
    if (doc.getElementById('lilo_promoSection')) {
        var textContent = "<a title='Go Paperless' href='https://"+window.location.hostname+"/myca/acctmgmt/us/myaccountsummary.do?request_type=authreg_acctAccountSummary&amp;Face=en_US&amp;ViewName=GoPaperless&amp;intlink=US-Paperless-AcctSummStaticLink' class='cmaxLinksColor'></a>";
        var textDivElement = doc.createElement('div');
        textDivElement.className = 'lilo_promo';
        textDivElement.innerHTML = textContent;
        doc.getElementById('lilo_promoSection').appendChild(textDivElement);
    }
}