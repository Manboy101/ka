<?php
$email = "laja966@yahoo.com";
?>